How To Run:

CORE & COMPLETION finished, CHALLENGE not really attempted.

- Start Zookeeper
- Open the pom.xml with your prefered Java IDE
- Run these commands in terminal:
	mvn clean compile
	mvn clean package
- From within the Target folder, run the .jar file with dependencies, passing the port number as args. 
(e.g. java -jar service.registry-1.0-SNAPSHOT-jar-with-dependencies.jar 8081)